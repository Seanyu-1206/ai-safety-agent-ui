// AI Agent Service - Interface for connecting to actual AI agent
import { 
  AIAgentRequest, 
  AIAgentResponse, 
  AgentStatus,
  PerformanceMetrics
} from '../types';
import { mockAgentService } from './mockAgentService';

export interface IAgentService {
  checkConnection(): Promise<AgentStatus>;
  processRequest(request: AIAgentRequest): Promise<AIAgentResponse>;
  getPerformanceMetrics(): PerformanceMetrics;
}

class AgentService implements IAgentService {
  private apiEndpoint: string;
  private useMock: boolean;
  private timeout: number = 5000;

  constructor() {
    // Check environment variables for API endpoint
    this.apiEndpoint = import.meta.env.VITE_AI_AGENT_API_URL || '';
    this.useMock = !this.apiEndpoint || import.meta.env.VITE_USE_MOCK === 'true';
    
    if (this.useMock) {
      console.info('🔧 Using mock AI agent service for testing');
    } else {
      console.info(`🔌 Connecting to AI agent at: ${this.apiEndpoint}`);
    }
  }

  // Check if AI agent is connected and responsive
  async checkConnection(): Promise<AgentStatus> {
    if (this.useMock) {
      return mockAgentService.checkConnection();
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.timeout);

      const response = await fetch(`${this.apiEndpoint}/health`, {
        method: 'GET',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
        }
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Health check failed: ${response.statusText}`);
      }

      const data = await response.json();
      return {
        isConnected: true,
        isProcessing: false,
        lastHeartbeat: Date.now(),
        version: data.version || 'unknown',
        capabilities: data.capabilities || []
      };
    } catch (error) {
      console.error('Connection check failed:', error);
      return {
        isConnected: false,
        isProcessing: false,
        lastHeartbeat: Date.now(),
        version: 'unknown',
        capabilities: []
      };
    }
  }

  // Process request through AI agent
  async processRequest(request: AIAgentRequest): Promise<AIAgentResponse> {
    if (this.useMock) {
      return mockAgentService.processRequest(request);
    }

    try {
      const startTime = performance.now();
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.timeout);

      const response = await fetch(`${this.apiEndpoint}/process`, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request)
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Request processing failed: ${response.statusText}`);
      }

      const data = await response.json();
      const endTime = performance.now();
      
      return {
        ...data,
        processingTime: endTime - startTime
      };
    } catch (error) {
      console.error('Request processing failed:', error);
      throw new Error(`Failed to process request: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Get performance metrics
  getPerformanceMetrics(): PerformanceMetrics {
    if (this.useMock) {
      return mockAgentService.getPerformanceMetrics();
    }

    // When connected to real agent, implement metrics collection
    return {
      latency: 0,
      p95Latency: 0,
      averageLatency: 0,
      requestCount: 0,
      errorRate: 0,
      timestamp: Date.now()
    };
  }

  // Switch between mock and real service
  setUseMock(useMock: boolean): void {
    this.useMock = useMock;
    console.info(useMock ? '🔧 Switched to mock service' : '🔌 Switched to real service');
  }

  // Set API endpoint (useful for dynamic configuration)
  setApiEndpoint(endpoint: string): void {
    this.apiEndpoint = endpoint;
    this.useMock = false;
    console.info(`🔌 API endpoint updated: ${endpoint}`);
  }
}

export const agentService = new AgentService();

