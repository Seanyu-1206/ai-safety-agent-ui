import React from 'react';
import { AgentInterface } from './components/AgentInterface';
import './styles/index.css';

function App() {
  return (
    <>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <div id="main-content">
        <AgentInterface />
      </div>
    </>
  );
}

export default App;

