// Core types for AI Safety Agent UI Integration

export interface AIAgentRequest {
  id: string;
  prompt: string;
  context?: Record<string, unknown>;
  timestamp: number;
  userId?: string;
  sessionId?: string;
}

export interface AIAgentResponse {
  id: string;
  requestId: string;
  content: string;
  confidence: number;
  riskLevel: RiskLevel;
  safetyFlags: SafetyFlag[];
  processingTime: number;
  timestamp: number;
}

export enum RiskLevel {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

export interface SafetyFlag {
  type: SafetyFlagType;
  severity: 'info' | 'warning' | 'error' | 'critical';
  message: string;
  details?: string;
}

export enum SafetyFlagType {
  CONTENT_POLICY = 'content_policy',
  BIAS_DETECTION = 'bias_detection',
  HARMFUL_CONTENT = 'harmful_content',
  PRIVACY_CONCERN = 'privacy_concern',
  MISINFORMATION = 'misinformation',
  ETHICAL_CONCERN = 'ethical_concern'
}

export interface PerformanceMetrics {
  latency: number;
  p95Latency: number;
  averageLatency: number;
  requestCount: number;
  errorRate: number;
  timestamp: number;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: string[];
}

export interface ValidationError {
  field: string;
  message: string;
  code: string;
}

export interface AgentStatus {
  isConnected: boolean;
  isProcessing: boolean;
  lastHeartbeat: number;
  version: string;
  capabilities: string[];
}

export interface UIConfig {
  maxRetries: number;
  timeoutMs: number;
  maxLatencyMs: number;
  enableDebugMode: boolean;
  accessibilityMode: 'standard' | 'high-contrast' | 'screen-reader';
}

