// Main Agent Interface Component
import React, { useState, useRef, useEffect } from 'react';
import { useAgentService } from '../hooks/useAgentService';
import { validatePrompt, sanitizeInput } from '../utils/validation';
import { announceToScreenReader } from '../utils/accessibility';
import { StatusIndicator } from './StatusIndicator';
import { SafetyFlagDisplay } from './SafetyFlagDisplay';
import { RiskLevelBadge } from './RiskLevelBadge';
import { PerformanceMonitor } from './PerformanceMonitor';
import './AgentInterface.css';

export const AgentInterface: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const {
    status,
    isLoading,
    error,
    response,
    metrics,
    sendRequest,
    checkConnection,
    clearError,
    clearResponse
  } = useAgentService();

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [prompt]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Clear previous errors
    setValidationErrors([]);
    clearError();
    
    // Sanitize input
    const sanitized = sanitizeInput(prompt);
    
    // Validate prompt
    const validation = validatePrompt(sanitized);
    
    if (!validation.isValid) {
      const errors = validation.errors.map(err => err.message);
      setValidationErrors(errors);
      announceToScreenReader(errors.join('. '), 'assertive');
      return;
    }
    
    // Show warnings if any
    if (validation.warnings.length > 0) {
      console.warn('Validation warnings:', validation.warnings);
    }
    
    // Send request
    await sendRequest(sanitized);
    announceToScreenReader('Request sent to AI safety agent', 'polite');
  };

  const handleClear = () => {
    setPrompt('');
    setValidationErrors([]);
    clearError();
    clearResponse();
    textareaRef.current?.focus();
    announceToScreenReader('Input cleared', 'polite');
  };

  const handlePromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setPrompt(e.target.value);
    if (validationErrors.length > 0) {
      setValidationErrors([]);
    }
    if (error) {
      clearError();
    }
  };

  return (
    <div className="agent-interface">
      <header className="agent-header">
        <h1 className="agent-title">AI Safety Agent</h1>
        <p className="agent-subtitle">UNICC Sandbox Integration</p>
        <StatusIndicator status={status} onRefresh={checkConnection} />
      </header>

      <main className="agent-main">
        <form onSubmit={handleSubmit} className="agent-form">
          <div className="form-group">
            <label htmlFor="prompt-input" className="form-label">
              Enter your prompt
              <span className="form-label-required" aria-label="required">*</span>
            </label>
            <textarea
              ref={textareaRef}
              id="prompt-input"
              className={`form-textarea ${validationErrors.length > 0 ? 'form-textarea-error' : ''}`}
              value={prompt}
              onChange={handlePromptChange}
              placeholder="Type your message here..."
              rows={4}
              disabled={isLoading || !status?.isConnected}
              aria-describedby={validationErrors.length > 0 ? 'validation-errors' : undefined}
              aria-invalid={validationErrors.length > 0}
            />
            {validationErrors.length > 0 && (
              <div 
                id="validation-errors" 
                className="form-errors"
                role="alert"
                aria-live="assertive"
              >
                {validationErrors.map((err, idx) => (
                  <p key={idx} className="form-error">{err}</p>
                ))}
              </div>
            )}
          </div>

          <div className="form-actions">
            <button
              type="submit"
              className="btn btn-primary"
              disabled={isLoading || !status?.isConnected || prompt.trim().length === 0}
              aria-label={isLoading ? 'Processing request' : 'Send request to AI agent'}
            >
              {isLoading ? (
                <>
                  <span className="btn-spinner" aria-hidden="true"></span>
                  Processing...
                </>
              ) : (
                'Send Request'
              )}
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={handleClear}
              disabled={isLoading || prompt.length === 0}
              aria-label="Clear input and response"
            >
              Clear
            </button>
          </div>
        </form>

        {error && (
          <div className="alert alert-error" role="alert" aria-live="assertive">
            <strong>Error:</strong> {error}
          </div>
        )}

        {response && (
          <section className="response-section" aria-labelledby="response-title">
            <h2 id="response-title" className="response-title">Response</h2>
            
            <div className="response-header">
              <RiskLevelBadge 
                riskLevel={response.riskLevel} 
                confidence={response.confidence}
              />
              <span className="response-time">
                Processed in {response.processingTime.toFixed(0)}ms
              </span>
            </div>

            <div className="response-content">
              <p>{response.content}</p>
            </div>

            <SafetyFlagDisplay flags={response.safetyFlags} />
          </section>
        )}

        <PerformanceMonitor metrics={metrics} />
      </main>
    </div>
  );
};

